caffeine_mg = float(input())
first_half=caffeine_mg // 2
print('After 6 hours: {:.2f} mg'.format(first_half))
second_half=first_half // 2
print('After 12 hours: {:.2f} mg'.format(second_half))
third_half=second_half / 4
print('After 24 hours: {:.2f} mg'.format(third_half))

