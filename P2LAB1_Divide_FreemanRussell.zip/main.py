user_num=int(input())
x=int(input())
y=user_num // x
z=y // x
t=z // x
print(y, end=' ')
print(z, end=' ')
print(t)
